<?php
session_start();
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>

<html>
<head>
<title>Admin panel</title>
<link rel="stylesheet" href="admin_style.css" media="all">
</head>
<body>
<div id="header">
<center>

	<a href="index.php"><h1 id="headtitle">
<img src="../images/admin.png" width="80" height="80" id="admin">Welcome to the Admin Panel</h1></a></center>
</div>
<div id="sidebar">.
<center>
	<h2><a href="view_posts.php">View all posts</a></h2>
	<h2><a href="insert_post.php">Insert New Posts</a></h2>
	<h2><a href="">View comments</a></h2>
	<h2><a href="logout.php">Logout</a></h2>
</center>
		
</div>
<div id="Welcome">
<center>
	<h1>Welcome to your Admin Panel</h1>
	<p>This is the admin panel for the personal website.The page contains the information of the website.</p>
	</center>
</div>

</body>
</html>
<?php } ?>