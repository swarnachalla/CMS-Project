<?php
session_start();
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>
<html>
<head>
<title>Admin panel</title>
<link rel="stylesheet" href="admin_style.css" media="all">
</head>
<body>
<div id="header">
	<center><a href="index.php"><h1 id="headtitle">Welcome to the Admin Panel</h1></a></center>
</div>
<div id="sidebar">.
<center>
	<h2><a href="view_posts.php">View all posts</a></h2>
	<h2><a href="insert_post.php">Insert New Posts</a></h2>
	<h2><a href="">View comments</a></h2>
	<h2><a href="logout.php">Logout</a></h2>
</center>
</div>
<style>
td {color:black; font-family: comic sans MS; background: wheat;}
#id {background: darkgoldenrod;}
</style>
<form method="post" action="insert_post.php" enctype="multipart/form-data">
<table  width="600" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>Insert New Post</i></b></h1></td>
</tr>
<tr>
<td>post title:</td>
<td><input type="text" name="title" ></td>
</tr>
<tr>
<td>post date:</td>
<td><input type="date" name="date"></td>
</tr>
<tr>
<td>post athor:</td>
<td><input type="text" name="author"></td>
</tr>
<tr>
<td>post keywords:</td>
<td><input type="text" name="keywords"></td>
</tr>
<tr>
<td>post image:</td>
<td><input type="file" name="image"></td>
</tr>
<tr>
<td>post content:</td>
<td><textarea name="text" cols="40" rows="20"></textarea></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="submit" value="publish"></td>
</tr>
</table>
</form>
<?php
include("includes/connect.php");

if(isset($_POST['submit'])){
	 $post_title=$_POST['title'];
	 $post_date=date('d-m-y');
	 $post_author=$_POST['author'];
	 $post_keywords=$_POST['keywords'];
	 $post_content=$_POST['text'];
	 $post_image=$_FILES['image']['name'];
	 $image_tmp=$_FILES['image']['tmp_name'];
	 if(empty($post_title)||empty($post_date)||empty($post_author)||empty($post_keywords)||empty($post_content)||empty($post_image)){
		echo "<script>alert('some field is empty please enter')</script>";
		exit(); 
	}
	else{
		move_uploaded_file($image_tmp, "../images/$post_image");
	    $query="insert into posts (post_title,post_date,post_author,post_image,post_keywords,post_content) values('$post_title','$post_date','$post_author','$post_image','$post_keywords','$post_content')";
		if(mysqli_query($con,$query)){
			echo '<center><h1 >post has been posted successfully</h1></center>';
		}

	}


}
}