<?php
session_start();
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>
<html>
<head>
<title>Admin panel</title>
<link rel="stylesheet" href="admin_style.css" media="all">
</head>
<body>
<div id="header">
	<center><a href="index.php"><h1 id="headtitle">Welcome to the Admin Panel</h1></a></center>
</div>
<div id="sidebar">.
<center>
	<h2><a href="view_posts.php">View all posts</a></h2>
	<h2><a href="insert_post.php">Insert New Posts</a></h2>
	<h2><a href="">View comments</a></h2>
	<h2><a href="logout.php">Logout</a></h2>
</center>
		
</div>
<?php 
include("includes/connect.php");
if (isset($_GET['edit'])){
	$edit_id=$_GET['edit'];
	$query="select * from posts where post_id='$edit_id'";
	$run=mysqli_query($con,$query);
	while ($row=mysqli_fetch_assoc($run)) {
	 $post_id=$row['post_id'];
	 $post_title=$row['post_title'];
	 $post_date=$row['post_date'];
	 $post_author=$row['post_author'];
     $post_keywords=$row['post_keywords'];
     $post_image=$row['post_image'];
     $post_content=$row['post_content'];
 }
}
     ?>
 

<style>
td {color:black; font-family: comic sans MS; background: wheat;}
#id {background: darkgoldenrod;}
</style>
<form method="post" action="edit.php?edit_form=<?php echo $post_id;?>"  enctype="multipart/form-data">
<table  width="600" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>Update your Post</i></b></h1></td>
</tr>
<tr>
<td>post title:</td>
<td><input type="text" name="title"  value="<?php echo $post_title;?>"></td>
</tr>
<tr>
<td>post date:</td>
<td><input type="date" name="date" value="<?php echo $post_date;?>"></td>
</tr>
<tr>
<td>post athor:</td>
<td><input type="text" name="author" value="<?php echo $post_author;?>"></td>
</tr>
<tr>
<td>post keywords:</td>
<td><input type="text" name="keywords" value="<?php echo $post_keywords;?>"></td>
</tr>
<tr>
<td>post image:</td>
<td>
<input type="file" name="image">
<img src="../images/<?php echo $post_image;?>" width="100" height="100" value="<?php echo $post_image?>"></td>
</tr>
<tr>
<td>post content:</td>
<td><textarea name="text" cols="40" rows="20"> <?php echo $post_content;?></textarea></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="submit" value="update"></td>
</tr>
</table>
</form>
<?php
include("includes/connect.php");

if(isset($_POST['submit'])){
	$update_id=$_GET['edit_form'];

	 $post_title1=$_POST['title'];
	 $post_date1=date('d-m-y');
	 $post_author1=$_POST['author'];
	 $post_keywords1=$_POST['keywords'];
	 $post_content1=$_POST['text'];
	 $post_image1=$_FILES['image']['name'];
	 $image_tmp1=$_FILES['image']['tmp_name'];
	 if(empty($post_title1)||empty($post_date1)||empty($post_author1)||empty($post_keywords1)||empty($post_content1)||empty($post_image1)){
		echo "<script>alert('some field is empty please enter')</script>";
		echo "<script>window.open('edit.php','edit.php?edit_form=<?php echo $update_id; ?>')</script>";
		die(); 
	}
	else{
		move_uploaded_file($image_tmp1, "../images/$post_image1");
	    $query_update="update posts set post_title='$post_title1',post_date='$post_date1',post_author='$post_author1',post_keywords='$post_keywords1',post_content='$post_content1',post_image='$post_image1' where post_id='$update_id'";
	    $update_run=mysql_query($query_update);
		if( $update_run){
			echo '<center><h1 >post has been updated successfully</h1></center>';
			echo "<script>alert('your post has been updated successfully')</script>";
			echo "<script>window.open('view_posts.php','_self')</script>";
		}
		else{
			echo "<script>alert('error in updating...please try again')</script>";
			echo "<script>window.open('view_posts.php','_self')</script>";
		}

	}


}
}
?>
