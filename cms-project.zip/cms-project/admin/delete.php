<?php
session_start();
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
include('includes/connect.php');
if(isset($_GET['del'])){
	$del_id=$_GET['del'];
	$query="delete from posts where post_id=$del_id";
	if(mysqli_query($con,$query)){
		echo "<script>alert('post has been deleted')</script>";
		echo "<script>window.open('view_posts.php','_self')</script>";
	}
}
}