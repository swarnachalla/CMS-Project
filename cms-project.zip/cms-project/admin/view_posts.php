<?php
session_start();
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>
<html>
<head>
<title>Admin panel</title>
<link rel="stylesheet" href="admin_style.css" media="all">
</head>
<body>
<div id="header">
	<center><a href="index.php"><h1 id="headtitle">View all your posts here.</h1></a></center>
</div>
<div id="sidebar">.
<center>
	<h2><a href="view_posts.php">View all posts</a></h2>
	<h2><a href="insert_post.php">Insert New Posts</a></h2>
	<h2><a href="">View comments</a></h2>
	<h2><a href="logout.php">Logout</a></h2>
</center>
		
</div>
<div id="Welcome">
<table width="1085" border="5" bgcolor="silver" >
	<tr >
		<td align="center" colspan="10" bgcolor="orange">View all posts</td>
	</tr>
	<tr bgcolor="wheat">
		<td>post no</td>
		<td>post title</td>
		<td>post date</td>
		<td>post author</td>
		<td>post image</td>
		<td>post keywords</td>
		<td>post content</td>
		<td>Delete post</td>
		<td>Edit post</td>
	</tr>
	<tr>
	<?php
include('includes/connect.php');
$query="select * from posts order by  1 DESC ";
$run=mysqli_query($con,$query);
while ($row=mysqli_fetch_assoc($run)) {
	 $post_id=$row['post_id'];
	 $post_title=$row['post_title'];
	 $post_date=$row['post_date'];
	 $post_author=$row['post_author'];
     $post_keywords=$row['post_keywords'];
     $post_image=$row['post_image'];
     $post_content=substr($row['post_content'],0,80);
     ?>
		<td><?php echo $post_id ; ?></td>
		<td><?php echo $post_title; ?></td>
		<td><?php echo $post_date ; ?></td>
		<td><?php echo $post_author ; ?></td>
		<td><img src="../images/<?php echo $post_image; ?>" width="80" height="80"</td>
		<td><?php echo $post_keywords ; ?></td>
		<td><?php echo $post_content ; ?></td>
		<td><a href="delete.php?del=<?php echo $post_id;?>"><center><img src="../images/delete.jpg" width="30" height="30"></center></a></td>
		<td><a href="edit.php?edit=<?php echo $post_id;?>"><center><img src="../images/edit.jpg" width="30" height="30"></center></a></td>
	</tr>
	<?php } ?>
</table>
</div>

</body>
<?php } ?>