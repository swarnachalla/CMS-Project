<?php
session_start();
?>
<html>
<head>
	<title>Admin login page</title>
</head>
<style >
body{background: gray;}
	td{ background: wheat; }
	#log{background: darkgoldenrod;}
	table{margin-top: 250px; border: 10px inline black}
</style>
<body>
<form method="POST" action="login.php">
	<table width="400" border="10" align="center" >
		<tr  align="center">
			<center><td id="log"colspan="4" >please login here</td></center>
		</tr>
		<tr>
		<td>username</td>
		<td><input type="text" name="user_name" ></td>
		</tr>
		<tr>
		<td>password</td>
		<td><input type="password" name="user_pass"></td>
		</tr>
		<tr>
		<td align="center" colspan="4"><input type="submit" name="submit" value="login"></td>
		</tr>
	</table>
	</form>
	<?php 
	include("includes/connect.php");
	if(isset($_POST['submit'])){
		$user_name=$_POST['user_name'];
		$users_pass=$_POST['user_pass'];
		$user_pass=md5($users_pass);
		$query="select * from login where user_name='$user_name' AND user_pass='$user_pass'";
		$run=mysqli_query($con,$query);
		if(empty($_POST['user_name'])||empty($_POST['user_pass'])){
         echo "<script>alert('some field is empty')</script>";
         echo "<script>window.open('login.php','_self')</script>";
		}
		else{
			if(mysqli_num_rows($run)==0){
				echo "<script>alert('username or password is typed incorrectly , please try again ')</script>";
			echo "<script>window.open('login.php','_self')</script>";
			}
		else if(mysqli_num_rows($run)==1){
			$_SESSION['user_name']=$user_name;
			echo "<script>window.open('index.php','_self')</script>";
		}
		
	}
}
?>