<html>
<head>
<title>ibrahim's cms</title>
<link rel="stylesheet" href="styles.css" media="all">
<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
</head>
<body>
<div><?php include('includes/header.php');?></div>
<div><?php include('includes/navbar.php');?></div>
<div id="content">
<?php
include("includes/connect.php");
if(isset($_GET['submit'])){
	$search=$_GET['value'];
	$query="select * from posts where post_keywords like '%$search%'";
	$run=mysqli_query($con,$query);
?>
<center><h2>your search result is here</h2></center>
<?php
	while ($row=mysqli_fetch_assoc($run)) {
	 $post_id=$row['post_id'];
	 $post_title=$row['post_title'];
     $post_image=$row['post_image'];
      $post_content=substr($row['post_content'],0,200);
?>
<p id='p'><a href ="pages.php?id=<?php echo $post_id;?>"><b><i><?php echo $post_title;?></i></b></a></p>
     <a href ="pages.php?id=<?php echo $post_id;?>">
     <center><img src="images/<?php echo $post_image; ?>" width="300" height="200"></center></a>
      <p id="content_font" align="justify"><?php echo $post_content; ?></p>
<?php } } ?>
</div>
<div><?php include('includes/sidebar.php');?></div>
<div><?php include('includes/footer.php');?></div>
?>
</body>
</html>