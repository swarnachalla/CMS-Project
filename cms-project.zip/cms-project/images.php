<html>
<head>
<title>ibrahim's cms</title>
<link rel="stylesheet" href="styles.css" media="all">
</head>
<body>

<div><?php include('includes/header.php');?></div>
<div><?php include('includes/navbar.php');?></div>
<div>
<div><?php include('includes/images.php');?></div>
<div><?php include('includes/sidebar.php');?></div>
</div>
<div><?php include('includes/footer.php');?></div>

</body>
</html>