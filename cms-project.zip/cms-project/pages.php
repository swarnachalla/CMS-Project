<html>
<head>
<title>ibrahim's cms</title>
<link rel="stylesheet" href="styles.css" media="all">
</head>
<body>
<?php
include('includes/header.php');
include('includes/navbar.php');
?>
<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
<div id="content">

<?php
include'connect.php';
if(isset($_GET['id'])){
$post_id=$_GET['id'];
$query="select * from posts where post_id='$post_id'";
$run=mysqli_query($con,$query);
while ($row=mysqli_fetch_assoc($run)) {
	 $post_id=$row['post_id'];
	 $post_title=$row['post_title'];
	 $post_date=$row['post_date'];
	 $post_author=$row['post_author'];
     $post_keywords=$row['post_keywords'];
     $post_image=$row['post_image'];
     $post_content=$row['post_content'];
     ?>

     <p id='p'><a href ="pages.php?id=<?php echo $post_id;?>"><b><i><?php echo $post_title;?></i></b></a></p>
     <center><img src="images/<?php echo $post_image; ?>" width="500" height="400"></center>
     <p>published on:<b><?php echo $post_date;?></b></p>
     <p id="content_font" align="justify"><?php echo $post_content; ?></p>
     <p align="right">published by:<b><?php echo $post_author;?></b></p><hr>
     
<?php	 
} }
?>
</div>
<?php
include('includes/sidebar.php');
include('includes/footer.php');
?>
</body>
</html>