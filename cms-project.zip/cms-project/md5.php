<?php
if(isset($_POST['submit'])){
	echo $data=md5($_POST['pass']).'<br>';
	echo $md5data=$data;
}
?>
<form method="POST" action="md5.php">
	<input type="text" name="pass">

	<input type="submit" name="submit">
</form>