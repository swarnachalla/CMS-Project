<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
<div id="content">


<h1> About Me</h1>

<h2> Pesonal details :</h2>
<!--Even though the template uses bulleted lists, you don't have to.  A simple paragraph format will work just as well.-->
<ul>
	<li><b>Name</b>    : Mohammed Ibrahim Khan Pathan<br></li>
	<li><b>Mail</b> : pathanmohammedibrahimkhan@gmail.com<br></li>
	<li><b>Contact</b> : 9030384207<br></li>
	<li><b>Skill </b>  : Web Developer</li>
	
</ul>
<h2> Education :</h2>
<ul>
	<li><b>B-tech</b> : Jawaharlal Technological Univsersity Ananthapur<br></li>
	<li><b>Intermediate</b> : Narayana college Nellore<br></li>
	<li><b>Schooling</b> : Infant Jesus High School Rajampet</li>
</ul>
<h2>List of sites associated :</h2>
<ul>

	<li>http://ibrahimkhan.me<br></li>
	<li>http://jntua.ibrahimkhan.me<br></li>
	<li>http://cmsphp.ibrahimkhan.me<br></li>
</ul>


<p>
<strong>ibrahimkhan.me</strong>
<br>
4/74-A usman nagar Rajampet
<br>
India
<p></p>
</div>

        