<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
<div id="content">


<h1> About Me</h1>

<h2> Pesonal details :</h2>
<!--Even though the template uses bulleted lists, you don't have to.  A simple paragraph format will work just as well.-->
<ul>
	<li><b>Name</b>    : Challa Swarna Bharathi<br></li>
	<li><b>Mail</b> : swarnabharathi1497@gmail.com<br></li>
	<li><b>Contact</b> : 9963131205<br></li>
	<li><b>Skill </b>  : Web Developer</li>
	
</ul>
<h2> Education :</h2>
<ul>
	<li><b>B-tech</b> : Jawaharlal Technological Univsersity Ananthapur<br></li>
	<li><b>Intermediate</b> : NRI Academy Tirupathi<br></li>
	<li><b>Schooling</b> : Sri Venkateshwara English Medium School</li>
</ul>
<h2>List of sites associated :</h2>
<ul>

	
	<li>http://http://github.com/swarnachalla/e-commerce-project<br></li>
	<li>http://http://github.com/swarnachalla/cms-project<br></li>
</ul>


<p>
<strong>Swarna Bharathi C</strong>
<br>
13/94 New Gandhi Nagar Chennur
<br>
India
<p></p>
</div>

        