<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
<div id="content">
<?php
include('connect.php');
?>
<table width="700" border="5" bgcolor="silver" >
	<tr >
		<td align="center" colspan="10" bgcolor="orange">View all posts</td>
	</tr>
	<tr bgcolor="wheat">
		<td>post no</td>
		<td>post title</td>
		<td>post date</td>
		<td>post author</td>
		<td>post image</td>
		
	</tr>
	<tr>
	<?php
include('includes/connect.php');
$query="select * from posts order by  1 ";
$run=mysqli_query($con,$query);
while ($row=mysqli_fetch_assoc($run)) {
	 $post_id=$row['post_id'];
	 $post_title=$row['post_title'];
	 $post_date=$row['post_date'];
	 $post_author=$row['post_author'];
     $post_keywords=$row['post_keywords'];
     $post_image=$row['post_image'];
    
     ?>
		<td><?php echo $post_id ; ?></td>
		<td><?php echo $post_title; ?></td>
		<td><?php echo $post_date ; ?></td>
		<td><?php echo $post_author ; ?></td>
		<td><img src="images/<?php echo $post_image; ?>" width="80" height="80"</td>
		
	</tr>
	<?php } ?>
</table>


</div>

</body>
