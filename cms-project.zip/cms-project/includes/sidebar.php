<style>
	ul li{list-style: none; display: inline;}
ul li{padding: 10px;}
h2{color: yellow; background: grey;}
#searchbox { margin-top: 10px; }
</style>
<div id="sidebar">
<center>
<div id="searchbox">
	<form method="GET" action="search.php" enctype="multipart/form-data">
	<input type="text" name="value" placeholder="search the content here">
	<input type="submit" value="search" name="submit">	
	</form>
</div>
</center>
<center><h2 ><i>connect us on:</i></h2></center>
<ul >
<li><a href="http://www.facebook.com/pathanmohammedibrahimkhan@gmail.com"><img src="images/facebook.png" alt="facebook" title="connect us on facebook" width="50" height="50"></a></li>
<li><a href="http://www.twitter.com/pathanmohammedibrahimkhan@gmail.com"><img src="images/twitter.png" alt="facebook" title="connect us on twitter" width="50" height="50"></a></li>
<li><a href="http://www.instagram.com/pathanmohammedibrahimkhan@gmail.com"><img src="images/instagram.png" alt="facebook" title="connect us on instagram" width="50" height="50"></a></li>
</ul>
<div id="recent_posts">
<?php
include("includes/connect.php");
$query="select * from posts order by 1 DESC LIMIT 0,5";
$run=mysqli_query($con,$query);
?>
<center><h2>recent posts</h2></center>
<?php
while ($row=mysqli_fetch_assoc($run)){
	$title=$row['post_title'];
	$post_id=$row['post_id'];
	$post_image=$row['post_image'];
	?>
	<center>
		<h3><a href ="pages.php?id=<?php echo $post_id;?>"><?php echo $title;?></a></h3>
		<a href ="pages.php?id=<?php echo $post_id;?>"><img src="images/<?php echo $post_image; ?>" width="100" height="100"></a>
	</center>
<?php } ?>
</div>
</div>