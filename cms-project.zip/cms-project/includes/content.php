<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
<div id="content">

<?php
include('connect.php');
$query="select * from posts order by rand() LIMIT 0,3";
$run=mysqli_query($con,$query);
while ($row=mysqli_fetch_assoc($run)) {
	 $post_id=$row['post_id'];
	 $post_title=$row['post_title'];
	 $post_date=$row['post_date'];
	 $post_author=$row['post_author'];
     $post_keywords=$row['post_keywords'];
     $post_image=$row['post_image'];
     $post_content=substr($row['post_content'],0,200);
     ?>

     <p id='p' padding="10"><a href ="pages.php?id=<?php echo $post_id;?>"><b><i><?php echo $post_title;?></i></b></a></p>
     <center><a href ="pages.php?id=<?php echo $post_id;?>"><img src="images/<?php echo $post_image; ?>" width="500" height="400"></a></center>
     <p >published on:<b><?php echo $post_date;?></b></p>
     <p id="content_font" align="justify"><?php echo $post_content; ?></p>
     <p align="right"><a href ="pages.php?id=<?php echo $post_id;?>">read more</a></p>
     <p align="right">published by:<b><?php echo $post_author;?></b></p><hr>
     
<?php	 
}
?>
</div>







