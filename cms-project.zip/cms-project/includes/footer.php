<div id="footer">

<center><address style="color: white, font-style: Times New Roman;"><b><i>
	&copy;Mohammed ibrahim khan pathan<br>
	pathanmohammedibrahimkhan@gmail.com<br>
	contact me: 9030384207<br>
	website: http://ibrahimkhan.me<br></b></i>
</address></center>


</div>