<style >
	#p {font-size: 24px; font-family: comic sans MS;}
	#contentfont{font-family: Times New Roman;}
	p {padding: 10px;}
</style>
<div id="content">
<?php
include('connect.php');

$query="select * from posts ";
$run=mysqli_query($con,$query);

while ($row=mysqli_fetch_assoc($run)) {
	  $post_id=$row['post_id'];
      $post_image=$row['post_image'];
?>
     <center><a href ="pages.php?id=<?php echo $post_id;?>"><img src="images/<?php echo $post_image; ?>" width="300" height="300"></a><br><br><br><br><br></center>


<?php	 
}
?>



</div>	