<div id="navbar">
<ul id="ul">
<li><a href="index.php">Home</li>

<li><a href="images.php">Images</li>
<li><a href="allposts.php">All Posts</li>
<li><a href="about.php">About Us</li>
<li><a href="contact.php">Contact</li>
</ul>
</div>