<div id="header">
<div id="logo">
<img src="images/swarna2.jpg" alt="swarna" width="100" height="120">
</div>
   Content Management System<br>
   A PHP coded cms project
<div id="add">
	<img src="images/banner.jpg" alt="add">
</div>


</div>