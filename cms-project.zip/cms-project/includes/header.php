<div id="header">
<div id="logo">
<img src="images/ibrahim2.jpg" alt="ibrahim">
</div>
   Content Management System<br>
   A PHP coded cms project
<div id="add">
	<img src="images/banner.jpg" alt="add">
</div>


</div>